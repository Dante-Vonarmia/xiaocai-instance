# flare-chat-core

Chat 核心能力包。

职责：

1. 会话状态与生命周期。
2. 输入状态与文件/拖拽处理。
3. SSE 流式通信与事件解析。
4. 消息时间线组装。

不包含：

1. Chat GUI 宿主层。
2. 生成式 UI 渲染层。

## 架构边界文档

1. `docs/SSOT-CHAT-CORE-BOUNDARY.md`（SSOT）
2. `docs/SSOT-CHAT-CORE-DATAFLOW.md`（引用型）
3. `docs/CHAT-CORE-BOUNDARY.md`（引用型）
4. `docs/CAPABILITY-INVENTORY.md`

## 构建

1. `npm run build`

## 本地启动

1. `npm run dev`
2. `npm run dev:real`

## Public entry

`src/index.js` 只暴露稳定 App 入口，不重新导出 `state`、`orchestration`、`adapters`、`contracts` 内部层。

## 运行模式与调试开关（Core）

Core 内置运行模式机制（`src/chat-core/runtime/runtimeMode.js`）：

1. `VITE_FLARE_CHAT_RUNTIME_MODE`：可选，`development` / `production`
2. `VITE_FLARE_CHAT_DEBUG`：可选，`1` 或 `true` 开启 debug 日志

规则：

1. **仅在非 production 模式下允许 debug 日志输出**
2. 即使设置了 `VITE_FLARE_CHAT_DEBUG=1`，若模式为 production 也不会输出调试日志
